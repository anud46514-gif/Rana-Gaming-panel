RANA GAMING PANEL - Android Studio Project

Target device:
- OPPO A71
- Android 7.1.1 (API 25)
- 3 GB RAM

Project setup:
1. Extract this ZIP on a computer.
2. Install Android Studio.
3. Open the extracted RANA_GAMING_PANEL folder in Android Studio.
4. Allow Gradle sync. This project uses Android Gradle Plugin 3.5.4 and compile SDK 28.
5. If Android Studio asks to install Android SDK Platform 28, install it.
6. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK output will be under app/build/outputs/apk/debug/app-debug.apk.

Important limitations:
- This is a starter project, not a compiled APK.
- The three modes are safe app-level presets only:
  Performance keeps this app's screen awake.
  Balanced restores normal app brightness and screen timeout behavior.
  Battery Saver lowers this app's screen brightness.
- A normal Android app cannot force CPU/GPU performance modes or change Free Fire's internal graphics settings without privileged/root access.
- Android 7.1.1 does not provide a normal third-party app with reliable access to another app's real-time game FPS. The app displays screen refresh rate separately and clearly labels FPS as unavailable.
- Battery temperature and this app's memory use are device readings; app memory is not total free RAM.

No root, no game modification, no Free Fire account access.
\nStartup animation update:\n- 3D-style logo flip, zoom-in and green neon glow.\n- Dashboard fade-in and a short logo pulse.\n
MOBILE-ONLY APK BUILD (GitHub Actions):
1. On your phone, sign in/create a GitHub account at https://github.com.
2. Create a NEW repository named RANA-GAMING-PANEL. Choose Public or Private.
3. Upload the CONTENTS of this project folder (not the outer ZIP) to the repository.
   Important: include the hidden .github/workflows/build-apk.yml file. If GitHub mobile upload
   makes hidden folders difficult, use GitHub in your browser with Desktop site enabled.
4. Open the repository's Actions tab.
5. Select "Build RANA GAMING PANEL APK" and tap "Run workflow".
6. Wait for the run to finish successfully (green check).
7. Open that completed run, scroll to Artifacts, and download RANA-GAMING-PANEL-APK.
8. Extract the downloaded artifact ZIP; install app-debug.apk on your OPPO A71.

This workflow builds the APK in GitHub's cloud; it does not require Android Studio on your phone.
Never share your GitHub password or verification codes with anyone.
