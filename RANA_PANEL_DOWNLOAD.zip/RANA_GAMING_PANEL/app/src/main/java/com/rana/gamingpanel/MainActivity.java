package com.rana.gamingpanel;

import android.app.Activity;
import android.os.Bundle;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Debug;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(10, 15, 13);
    private final int CARD = Color.rgb(20, 29, 25);
    private final int GREEN = Color.rgb(38, 220, 116);
    private final int MUTED = Color.rgb(157, 177, 165);
    private TextView modeStatus, batteryValue, tempValue, ramValue, refreshValue, fpsValue;
    private String currentMode = "BALANCED";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5, 10, 8));
        getWindow().setNavigationBarColor(Color.rgb(5, 10, 8));
        buildScreen();
        updateDeviceInfo();
        applyMode("BALANCED");
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addGap(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, height));
    }

    private TextView makeButton(String label, String mode) {
        TextView b = text(label, 15, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(10, 18, 10, 18);
        b.setBackground(shape(Color.rgb(25, 55, 39), 18));
        b.setOnClickListener(v -> applyMode(mode));
        return b;
    }

    private void buildScreen() {
        LinearLayout root = column();
        root.setPadding(20, 24, 20, 22);
        root.setBackgroundColor(BG);

        TextView title = text("RANA GAMING PANEL", 23, GREEN, true);
        root.addView(title);
        TextView subtitle = text("FREE FIRE • DEVICE DASHBOARD", 11, MUTED, true);
        root.addView(subtitle);
        addGap(root, 22);

        TextView modeTitle = text("GAMING MODE", 13, MUTED, true);
        root.addView(modeTitle);
        addGap(root, 10);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView p = makeButton("PERFORMANCE", "PERFORMANCE");
        TextView b = makeButton("BALANCED", "BALANCED");
        TextView s = makeButton("BATTERY SAVER", "BATTERY");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(0, 0, 7, 0); row.addView(p, lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1);
        lp2.setMargins(0, 0, 7, 0); row.addView(b, lp2);
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(0, -2, 1);
        row.addView(s, lp3);
        root.addView(row);

        addGap(root, 12);
        modeStatus = text("ACTIVE: BALANCED", 13, GREEN, true);
        root.addView(modeStatus);

        addGap(root, 22);
        TextView statsTitle = text("DEVICE MONITOR", 13, MUTED, true);
        root.addView(statsTitle);
        addGap(root, 10);

        LinearLayout stats = column();
        stats.setPadding(16, 14, 16, 14);
        stats.setBackground(shape(CARD, 18));
        batteryValue = text("Battery: --", 17, Color.WHITE, true);
        tempValue = text("Battery temperature: --", 14, MUTED, false);
        ramValue = text("App memory: --", 14, MUTED, false);
        refreshValue = text("Display refresh rate: --", 14, MUTED, false);
        fpsValue = text("Game FPS: Not available", 17, GREEN, true);
        stats.addView(batteryValue); addGap(stats, 8);
        stats.addView(tempValue); addGap(stats, 8);
        stats.addView(ramValue); addGap(stats, 8);
        stats.addView(refreshValue); addGap(stats, 12);
        stats.addView(fpsValue);
        root.addView(stats);

        addGap(root, 16);
        TextView note = text("FPS NOTE: Android 7.1.1 does not let a normal app read Free Fire's real in-game FPS. The refresh-rate value is not the same as FPS.", 12, MUTED, false);
        root.addView(note);

        addGap(root, 16);
        TextView footer = text("Device target: OPPO A71 • Android 7.1.1 • 3GB RAM", 11, MUTED, false);
        root.addView(footer);

        setContentView(root);

        // 3D-style gaming intro: dashboard fades in while the logo flips and zooms forward.
        root.setAlpha(0f);
        root.setScaleX(0.97f);
        root.setScaleY(0.97f);
        title.setCameraDistance(9000f);
        title.setRotationX(65f);
        title.setRotationY(-18f);
        title.setScaleX(0.55f);
        title.setScaleY(0.55f);
        title.setAlpha(0f);
        title.setShadowLayer(18f, 0f, 0f, GREEN);

        root.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(650).start();

        title.animate().rotationX(0f).rotationY(0f)
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setStartDelay(120).setDuration(1050)
                .withEndAction(() -> {
                    title.animate().scaleX(1.025f).scaleY(1.025f)
                            .setDuration(350).withEndAction(() ->
                            title.animate().scaleX(1f).scaleY(1f)
                                    .setDuration(350).start()).start();
                }).start();

        subtitle.setAlpha(0f);
        subtitle.animate().alpha(1f).setStartDelay(700).setDuration(600).start();
    }

    private void applyMode(String mode) {
        currentMode = mode;
        Window w = getWindow();
        WindowManager.LayoutParams params = w.getAttributes();
        if ("PERFORMANCE".equals(mode)) {
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
            modeStatus.setText("ACTIVE: PERFORMANCE • SCREEN STAYS ON");
        } else if ("BATTERY".equals(mode)) {
            w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            params.screenBrightness = 0.35f;
            modeStatus.setText("ACTIVE: BATTERY SAVER • LOWER SCREEN BRIGHTNESS");
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
            modeStatus.setText("ACTIVE: BALANCED");
        }
        w.setAttributes(params);
        Toast.makeText(this, mode + " mode selected", Toast.LENGTH_SHORT).show();
    }

    private void updateDeviceInfo() {
        try {
            Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery != null) {
                int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                if (level >= 0 && scale > 0) batteryValue.setText("Battery: " + (level * 100 / scale) + "%");
                if (temp >= 0) tempValue.setText("Battery temperature: " + (temp / 10.0f) + " °C");
            }
            Debug.MemoryInfo mi = new Debug.MemoryInfo();
            Debug.getMemoryInfo(mi);
            ramValue.setText("This app memory: " + (mi.getTotalPss() / 1024) + " MB (not total free RAM)");
            float hz = getWindowManager().getDefaultDisplay().getRefreshRate();
            refreshValue.setText("Display refresh rate: " + String.format(java.util.Locale.US, "%.0f Hz", hz));
            fpsValue.setText("Game FPS: Not accessible on this Android version");
        } catch (Exception e) {
            Toast.makeText(this, "Some device stats are unavailable", Toast.LENGTH_SHORT).show();
        }
    }
}
